package com.triviagame;

import android.app.Activity;
import android.os.Bundle;


public class correctanswer extends Activity  {
	
	//This activity is launched when the player selects the correct answer
	
	@Override
	 protected void onCreate(Bundle savedInstanceState) {
	    
		super.onCreate(savedInstanceState);
	        setContentView(R.layout.correctansweractivity);
	      
	}


}