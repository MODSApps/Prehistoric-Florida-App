package com.triviagame;

import android.app.Activity;
import android.os.Bundle;

//This activity is displayed when the player selects the wrong answer
public class wronganswer extends Activity {
	
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.wrongansweractivity);

	 }
	 

}