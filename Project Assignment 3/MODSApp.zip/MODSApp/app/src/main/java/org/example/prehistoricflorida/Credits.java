package org.example.prehistoricflorida;

/**
 * Created by Marcus on 7/23/2015.
 */
import android.app.Activity;
import android.os.Bundle;

public class Credits extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.credits);
    }
}
