package org.example.prehistoricflorida.fossils;

import android.app.Activity;

/**
 * Created by Marcus on 7/22/2015.
 */
import android.os.Bundle;

import org.example.prehistoricflorida.R;

public class d_sloth extends Activity {
    private static final String TAG = "MODSApp";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_sloth);
    }
}
