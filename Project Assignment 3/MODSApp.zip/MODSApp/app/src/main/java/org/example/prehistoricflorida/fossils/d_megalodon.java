package org.example.prehistoricflorida.fossils;

/**
 * Created by Marcus on 7/22/2015.
 */
import android.app.Activity;
import android.os.Bundle;

import org.example.prehistoricflorida.R;

public class d_megalodon extends Activity{
    private static final String TAG = "MODSApp";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_megalodon);
    }
}
