package org.example.prehistoricflorida;

/**
 * Created by Marcus on 7/10/2015.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import org.example.prehistoricflorida.fossils.d_archelon;
import org.example.prehistoricflorida.fossils.d_mammoth;
import org.example.prehistoricflorida.fossils.d_megalodon;
import org.example.prehistoricflorida.fossils.d_sloth;


public class Fossils extends Activity implements OnClickListener {
    private static final String TAG = "MODSApp";
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fossilfinder);
        Log.d(TAG, "Layout set");

        //More Info Button
        View moreInfoButton = findViewById(R.id.moreinfo);
        moreInfoButton.setOnClickListener(this);
        View turtleFossilButton = findViewById(R.id.turtleFossil);
        turtleFossilButton.setOnClickListener(this);
        View megalodonToothButton = findViewById(R.id.megalodonTooth);
        megalodonToothButton.setOnClickListener(this);
        View slothClawButton = findViewById(R.id.slothClaw);
        slothClawButton.setOnClickListener(this);
        View mammothTuskButton = findViewById(R.id.mammothTusk);
        mammothTuskButton.setOnClickListener(this);

    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.moreinfo:
                Log.d(TAG, "clicked on more info button");
                Intent i = new Intent(this, FossilsMoreInfo.class);
                startActivity(i);
                break;
            case R.id.turtleFossil:
                Log.d(TAG, "clicked on turtle fossil button");
                Intent j = new Intent(this, d_archelon.class);
                startActivity(j);
                break;
            case R.id.megalodonTooth:
                Log.d(TAG, "clicked on megalodon tooth button");
                Intent k = new Intent(this, d_megalodon.class);
                startActivity(k);
                break;
            case R.id.slothClaw:
                Log.d(TAG, "clicked on sloth claw button");
                Intent l = new Intent(this, d_sloth.class);
                startActivity(l);
                break;
            case R.id.mammothTusk:
                Log.d(TAG, "clicked on mammoth tusk button");
                Intent m = new Intent(this, d_mammoth.class);
                startActivity(m);
                break;
        }
    }
}

